/**
 * Centralized Projects configuration for RAYHAN NWV
 * Matches the reference mockup while preserving content integrity.
 */

export interface ProjectItem {
  id: string;
  title: string;
  category: string;
  shortDescription: string;
  fullDescription: string;
  techStack: string[];
  image: string;
  demoUrl?: string;
  githubUrl: string;
  featured: boolean;
  statusBadge: string;
  releaseYear: string;
}

export const PROJECTS_HEADER = {
  sectionIndex: '02 / 05',
  sectionTitle: 'SELECTED',
  sectionTitleAccent: 'WORK.',
  subtitle:
    'A collection of my best projects, crafted with passion and cutting-edge technology.',
  ctaLabel: 'View All Projects',
};

export const PROJECTS_DATA: ProjectItem[] = [
  {
    id: 'rayhan-beyond',
    title: 'RAYHAN BEYOND',
    category: 'Portfolio Website',
    shortDescription: 'Premium Portfolio Website with dark editorial aesthetic and high-intensity motion choreography.',
    fullDescription:
      'A bespoke digital portfolio architecture exploring dark editorial aesthetics, responsive fluid typography, and precise GSAP scroll animations without reliance on heavy 3D runtimes.',
    techStack: ['React', 'TypeScript', 'Tailwind CSS', 'GSAP', 'Vite'],
    image: '/assets/portfolio/project-beyond.png',
    demoUrl: '#home',
    githubUrl: 'https://github.com/nwrayhan23-art/',
    featured: true,
    statusBadge: 'Active Concept',
    releaseYear: '2026',
  },
  {
    id: 'rayhan-capital',
    title: 'Rayhan Capital',
    category: 'Crypto Terminal',
    shortDescription: 'Futuristic digital asset terminal interface with real-time charting and order execution flows.',
    fullDescription:
      'Conceptual high-throughput cryptocurrency terminal interface featuring dark mode data density, responsive financial charts, multi-pair tracking, and rapid transaction flows.',
    techStack: ['TypeScript', 'React', 'WebSockets', 'Tailwind CSS'],
    image: '/assets/portfolio/project-capital.png',
    demoUrl: 'https://github.com/nwrayhan23-art/',
    githubUrl: 'https://github.com/nwrayhan23-art/',
    featured: true,
    statusBadge: 'Concept Prototype',
    releaseYear: '2025',
  },
  {
    id: 'gaming-universe',
    title: 'Gaming Universe',
    category: 'Interactive Web',
    shortDescription: 'High-performance interactive web experience with cinematic environment pacing.',
    fullDescription:
      'Experimental web game architecture prioritizing lightweight canvas physics, smooth 60fps animations, procedural audio cues, and seamless mobile touch mechanics.',
    techStack: ['Canvas 2D', 'TypeScript', 'GSAP', 'Web Audio API'],
    image: '/assets/portfolio/project-gaming.png',
    demoUrl: 'https://github.com/nwrayhan23-art/',
    githubUrl: 'https://github.com/nwrayhan23-art/',
    featured: true,
    statusBadge: 'Experimental',
    releaseYear: '2025',
  },
  {
    id: 'business-tycoon',
    title: 'Business Tycoon',
    category: 'Android & Mobile',
    shortDescription: 'Economic strategy simulation designed for mobile platforms with intuitive management loops.',
    fullDescription:
      'Mobile economic simulation prototype modeling capital allocation, supply chain routing, and company scaling with lightweight reactive state management.',
    techStack: ['Android', 'Kotlin', 'TypeScript', 'State Management'],
    image: '/assets/portfolio/project-tycoon.png',
    demoUrl: 'https://github.com/nwrayhan23-art/',
    githubUrl: 'https://github.com/nwrayhan23-art/',
    featured: true,
    statusBadge: 'Prototype',
    releaseYear: '2024',
  },
];
