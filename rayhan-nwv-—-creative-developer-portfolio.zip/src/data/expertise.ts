/**
 * Centralized Expertise and Tech Exploration data
 * Honest, curiosity-driven interest areas without fake percentage meters.
 */

export interface CapabilityItem {
  id: string;
  title: string;
  iconName: 'code' | 'globe' | 'brain' | 'box' | 'rocket';
  subtitle: string;
  focusAreas: string[];
  description: string;
  isWide?: boolean;
}

export const EXPERTISE_HEADER = {
  sectionIndex: '04 / 05',
  sectionTitle: 'EXPLORING',
  sectionTitleAccent: 'TECHNOLOGY.',
  subtitle:
    "From code to innovation, I'm always curious about new technologies and their potential.",
  ctaLabel: 'Explore Focus Areas',
};

export const CAPABILITIES_DATA: CapabilityItem[] = [
  {
    id: 'programming',
    title: 'Programming',
    iconName: 'code',
    subtitle: 'Core Systems & Logic',
    focusAreas: ['TypeScript', 'JavaScript', 'Python', 'Algorithms', 'Clean Architecture'],
    description:
      'Writing expressive, maintainable, and resilient code across modular paradigms and computational problem solving.',
  },
  {
    id: 'web-development',
    title: 'Web Development',
    iconName: 'globe',
    subtitle: 'Modern Digital Interfaces',
    focusAreas: ['React', 'Next.js', 'Tailwind CSS', 'GSAP', 'Responsive Systems'],
    description:
      'Crafting high-speed, accessible, and motion-rich web applications that feel fluid across all modern devices.',
  },
  {
    id: 'artificial-intelligence',
    title: 'Artificial Intelligence',
    iconName: 'brain',
    subtitle: 'Generative Systems & Agents',
    focusAreas: ['LLM Orchestration', 'Prompt Engineering', 'AI APIs', 'Autonomous Agents'],
    description:
      'Investigating modern cognitive models, developer automation, neural architectures, and intelligent user interaction flows.',
  },
  {
    id: 'blockchain',
    title: 'Blockchain',
    iconName: 'box',
    subtitle: 'Decentralized Protocols',
    focusAreas: ['Smart Contracts', 'Web3 Architecture', 'Consensus Models', 'Crypto UX'],
    description:
      'Analyzing trust-minimized networks, cryptographic fundamentals, decentralized state, and resilient peer-to-peer protocols.',
  },
  {
    id: 'digital-innovation',
    title: 'Digital Innovation',
    iconName: 'rocket',
    subtitle: 'Creative Exploration & Emerging Tech',
    focusAreas: ['Motion Design', 'Interactive UI/UX', 'Performance Engineering', 'Future Tech'],
    description:
      'Pushing the boundaries of digital experiences by synthesizing design intuition, high-framerate motion, and cutting-edge web platforms.',
    isWide: true,
  },
];
