/**
 * Profile & Identity configuration for RAYHAN NWV
 * Centralized data source for personal branding, bio, and verified contact links.
 */

export interface NavItem {
  id: string;
  label: string;
  href: string;
}

export interface ProfileData {
  brandName: string;
  brandMark: string;
  headline: string;
  headlineAccent: string;
  subheadline: string;
  about: {
    sectionIndex: string;
    sectionTitle: string;
    sectionTitleAccent: string;
    greeting: string;
    bioParagraph1: string;
    bioParagraph2: string;
    avatarImage: string;
    badgeText: string;
  };
  contact: {
    sectionIndex: string;
    sectionTitle: string;
    sectionTitleAccent: string;
    description: string;
    github: {
      url: string;
      display: string;
      label: string;
    };
    whatsapp: {
      url: string;
      display: string;
      rawNumber: string;
      label: string;
    };
  };
  navLinks: NavItem[];
}

export const PROFILE_DATA: ProfileData = {
  brandName: 'RAYHAN NWV',
  brandMark: 'RN',
  headline: 'BUILDING BEYOND',
  headlineAccent: 'LIMITS.',
  subheadline:
    'Exploring technology, programming, and ideas that turn possibilities into digital experiences.',
  about: {
    sectionIndex: '01 / 05',
    sectionTitle: 'ABOUT',
    sectionTitleAccent: 'ME.',
    greeting: "Hi, I'm Rayhan.",
    bioParagraph1:
      'A developer and technology enthusiast who loves exploring the endless possibilities of the digital world.',
    bioParagraph2:
      'I am passionate about programming, web development, AI, blockchain, and building innovative projects that make an impact.',
    avatarImage: '/assets/portfolio/about-portrait.png',
    badgeText: 'RAYHAN NWV',
  },
  contact: {
    sectionIndex: '05 / 05',
    sectionTitle: "LET'S",
    sectionTitleAccent: 'CONNECT.',
    description:
      "Feel free to reach out, whether it's for collaboration, questions, or just to say hi!",
    github: {
      url: 'https://github.com/nwrayhan23-art/',
      display: 'github.com/nwrayhan23-art/',
      label: 'GitHub Profile',
    },
    whatsapp: {
      url: 'https://wa.me/62882003815325',
      display: '+62 882-0038-15325',
      rawNumber: '+62882003815325',
      label: 'WhatsApp Message',
    },
  },
  navLinks: [
    { id: 'home', label: 'Home', href: '#home' },
    { id: 'about', label: 'About', href: '#about' },
    { id: 'projects', label: 'Projects', href: '#projects' },
    { id: 'expertise', label: 'Expertise', href: '#expertise' },
    { id: 'contact', label: 'Contact', href: '#contact' },
  ],
};
