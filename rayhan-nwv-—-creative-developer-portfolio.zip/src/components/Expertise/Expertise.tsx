import React, { useState, useRef, useEffect } from 'react';
import {
  Code2,
  Globe,
  Brain,
  Box,
  Rocket,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { EXPERTISE_HEADER, CAPABILITIES_DATA, CapabilityItem } from '../../data/expertise';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const Expertise: React.FC = () => {
  const [activeItem, setActiveItem] = useState<string | null>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
      }

      gsap.fromTo(
        headerRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 75%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        cardsRef.current?.children || [],
        { opacity: 0, y: 35 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.12,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getIcon = (iconName: CapabilityItem['iconName']) => {
    switch (iconName) {
      case 'code':
        return <Code2 className="w-8 h-8 text-[#00D2FF]" />;
      case 'globe':
        return <Globe className="w-8 h-8 text-[#00D2FF]" />;
      case 'brain':
        return <Brain className="w-8 h-8 text-[#00D2FF]" />;
      case 'box':
        return <Box className="w-8 h-8 text-[#00D2FF]" />;
      case 'rocket':
        return <Rocket className="w-8 h-8 text-[#00D2FF]" />;
      default:
        return <Sparkles className="w-8 h-8 text-[#00D2FF]" />;
    }
  };

  const handleExploreMoreClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const el = document.getElementById('contact');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="expertise"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-[#05070D] border-t border-white/[0.06] overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 right-10 w-[450px] h-[450px] bg-[#00D2FF]/8 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Section Header Left */}
          <div ref={headerRef} className="lg:col-span-5 flex flex-col items-start">
            {/* Section Index */}
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-sm tracking-widest text-[#00D2FF] font-semibold">
                {EXPERTISE_HEADER.sectionIndex}
              </span>
              <div className="w-8 h-[1px] bg-[#00D2FF]/40" />
              <span className="font-mono text-xs uppercase tracking-widest text-[#8E9BB0]">
                CORE INTERESTS
              </span>
            </div>

            <h2 className="text-3xl sm:text-5xl md:text-6xl font-display font-bold text-white tracking-tight mb-6">
              {EXPERTISE_HEADER.sectionTitle}{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D2FF] to-[#0066FF] glow-cyan">
                {EXPERTISE_HEADER.sectionTitleAccent}
              </span>
            </h2>

            <p className="text-base sm:text-lg text-[#8E9BB0] leading-relaxed max-w-md mb-8">
              {EXPERTISE_HEADER.subtitle}
            </p>

            <a
              href="#contact"
              onClick={handleExploreMoreClick}
              className="group inline-flex items-center gap-3 px-6 py-3.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-white font-medium text-sm border border-white/[0.1] hover:border-[#00D2FF]/50 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.4)]"
            >
              <span>{EXPERTISE_HEADER.ctaLabel}</span>
              <ArrowRight className="w-4 h-4 text-[#00D2FF] transition-transform group-hover:translate-x-1" />
            </a>
          </div>

          {/* Capabilities Matrix Right */}
          <div
            ref={cardsRef}
            className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5"
          >
            {CAPABILITIES_DATA.map((item) => {
              const isSelected = activeItem === item.id;
              const isWide = item.isWide;

              return (
                <div
                  key={item.id}
                  onClick={() => setActiveItem(isSelected ? null : item.id)}
                  className={`group relative p-6 sm:p-7 rounded-2xl bg-[#0A0E17]/90 border border-white/[0.08] hover:border-[#00D2FF]/50 transition-all duration-300 cursor-pointer shadow-[0_10px_30px_rgba(0,0,0,0.5)] hover:shadow-[0_15px_35px_rgba(0,210,255,0.12)] ${
                    isWide ? 'sm:col-span-2' : ''
                  } ${
                    isSelected
                      ? 'border-[#00D2FF]/70 bg-[#0A0E17] shadow-[0_0_30px_rgba(0,210,255,0.2)]'
                      : ''
                  }`}
                >
                  {/* Subtle top-right icon indicator */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.08] group-hover:border-[#00D2FF]/40 group-hover:bg-[#00D2FF]/10 transition-colors">
                      {getIcon(item.iconName)}
                    </div>
                    <span className="font-mono text-xs text-[#8E9BB0]/60 group-hover:text-[#00D2FF] transition-colors">
                      [+]
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-display font-bold text-white group-hover:text-[#00D2FF] transition-colors mb-2">
                    {item.title}
                  </h3>

                  <p className="text-xs font-mono text-[#00D2FF]/80 uppercase tracking-wider mb-3">
                    {item.subtitle}
                  </p>

                  <p className="text-sm text-[#8E9BB0] leading-relaxed mb-4">
                    {item.description}
                  </p>

                  {/* Focus chips */}
                  <div className="flex flex-wrap gap-1.5 pt-3 border-t border-white/[0.06]">
                    {item.focusAreas.map((area) => (
                      <span
                        key={area}
                        className="px-2.5 py-1 rounded-md text-xs font-mono bg-white/[0.03] border border-white/[0.06] text-white/90 group-hover:border-[#00D2FF]/30 transition-colors"
                      >
                        {area}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
