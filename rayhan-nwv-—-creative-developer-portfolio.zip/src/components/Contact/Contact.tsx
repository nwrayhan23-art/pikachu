import React, { useState, useRef, useEffect } from 'react';
import { Github, MessageSquare, Copy, Check, ExternalLink } from 'lucide-react';
import { PROFILE_DATA } from '../../data/profile';
import { copyTextToClipboard } from '../../utils/portfolio';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const Contact: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const visualRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
      }

      gsap.fromTo(
        headerRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 75%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        cardsRef.current?.children || [],
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        visualRef.current,
        { opacity: 0, scale: 0.9 },
        {
          opacity: 1,
          scale: 1,
          duration: 1.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 75%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleCopyNumber = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const success = await copyTextToClipboard(PROFILE_DATA.contact.whatsapp.display);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-24 sm:py-36 bg-[#05070D] border-t border-white/[0.06] overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] bg-[#0066FF]/10 rounded-full blur-[180px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[450px] h-[450px] bg-[#00D2FF]/12 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Heading and Contact Cards */}
          <div className="lg:col-span-7 flex flex-col items-start">
            {/* Section Index */}
            <div ref={headerRef} className="w-full">
              <div className="flex items-center gap-3 mb-4">
                <span className="font-mono text-sm tracking-widest text-[#00D2FF] font-semibold">
                  {PROFILE_DATA.contact.sectionIndex}
                </span>
                <div className="w-8 h-[1px] bg-[#00D2FF]/40" />
                <span className="font-mono text-xs uppercase tracking-widest text-[#8E9BB0]">
                  GET IN TOUCH
                </span>
              </div>

              <h2 className="text-4xl sm:text-6xl md:text-7xl font-display font-extrabold text-white tracking-tight mb-6">
                {PROFILE_DATA.contact.sectionTitle}{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D2FF] to-[#0066FF] glow-cyan">
                  {PROFILE_DATA.contact.sectionTitleAccent}
                </span>
              </h2>

              <p className="text-base sm:text-lg text-[#8E9BB0] leading-relaxed max-w-xl mb-10">
                {PROFILE_DATA.contact.description}
              </p>
            </div>

            {/* Contact Action Cards */}
            <div ref={cardsRef} className="flex flex-col gap-4 w-full max-w-lg">
              {/* GitHub Card */}
              <a
                href={PROFILE_DATA.contact.github.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center justify-between p-5 sm:p-6 rounded-2xl bg-[#0A0E17]/90 border border-white/[0.08] hover:border-[#00D2FF]/60 hover:bg-[#0A0E17] transition-all duration-300 shadow-[0_10px_30px_rgba(0,0,0,0.5)] hover:shadow-[0_15px_35px_rgba(0,210,255,0.15)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF]"
              >
                <div className="flex items-center gap-4 sm:gap-5">
                  <div className="p-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white group-hover:text-[#00D2FF] group-hover:border-[#00D2FF]/40 transition-colors">
                    <Github className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-xs font-mono uppercase tracking-widest text-[#8E9BB0]">
                      Open Source
                    </span>
                    <h3 className="text-lg sm:text-xl font-display font-bold text-white group-hover:text-[#00D2FF] transition-colors">
                      GitHub
                    </h3>
                    <p className="text-xs sm:text-sm font-mono text-[#8E9BB0] group-hover:text-white/80 transition-colors">
                      {PROFILE_DATA.contact.github.display}
                    </p>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl text-white/60 group-hover:text-[#00D2FF] group-hover:translate-x-1 transition-all">
                  <ExternalLink className="w-5 h-5" />
                </div>
              </a>

              {/* WhatsApp Card */}
              <div className="group relative flex items-center justify-between p-5 sm:p-6 rounded-2xl bg-[#0A0E17]/90 border border-white/[0.08] hover:border-[#00D2FF]/60 transition-all duration-300 shadow-[0_10px_30px_rgba(0,0,0,0.5)] hover:shadow-[0_15px_35px_rgba(0,210,255,0.15)]">
                <a
                  href={PROFILE_DATA.contact.whatsapp.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 sm:gap-5 flex-grow focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF] rounded-xl"
                  title="Open chat on WhatsApp"
                >
                  <div className="p-3.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white group-hover:text-[#00D2FF] group-hover:border-[#00D2FF]/40 transition-colors">
                    <MessageSquare className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-xs font-mono uppercase tracking-widest text-[#8E9BB0]">
                      Direct Message
                    </span>
                    <h3 className="text-lg sm:text-xl font-display font-bold text-white group-hover:text-[#00D2FF] transition-colors">
                      WhatsApp
                    </h3>
                    <p className="text-xs sm:text-sm font-mono text-[#8E9BB0] group-hover:text-white/80 transition-colors">
                      {PROFILE_DATA.contact.whatsapp.display}
                    </p>
                  </div>
                </a>

                {/* Copy Number Action Button */}
                <div className="flex items-center gap-2 pl-3">
                  <button
                    onClick={handleCopyNumber}
                    aria-label="Copy WhatsApp phone number to clipboard"
                    title="Copy phone number"
                    className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.1] border border-white/[0.1] hover:border-[#00D2FF]/50 text-white/80 hover:text-[#00D2FF] transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF]"
                  >
                    {copied ? (
                      <Check className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <Copy className="w-5 h-5" />
                    )}
                  </button>

                  <a
                    href={PROFILE_DATA.contact.whatsapp.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Open WhatsApp conversation"
                    className="p-2.5 rounded-xl text-white/60 group-hover:text-[#00D2FF] group-hover:translate-x-1 transition-all"
                  >
                    <ExternalLink className="w-5 h-5" />
                  </a>
                </div>
              </div>

              {/* Copy Notification Toast Banner */}
              {copied && (
                <div
                  role="status"
                  aria-live="polite"
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#0066FF]/20 to-[#00D2FF]/20 border border-[#00D2FF]/40 text-xs font-mono text-[#00D2FF] flex items-center gap-2 animate-fadeIn"
                >
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Phone number copied to clipboard: {PROFILE_DATA.contact.whatsapp.display}</span>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Orbital Cosmic R Emblem */}
          <div ref={visualRef} className="lg:col-span-5 flex justify-center lg:justify-end">
            <div className="relative w-full max-w-[400px] sm:max-w-[440px] aspect-square flex items-center justify-center">
              {/* Outer atmospheric aura */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-[#0066FF]/25 via-[#00D2FF]/30 to-transparent blur-3xl pointer-events-none" />

              {/* Animated 2D Orbital Rings */}
              <div className="absolute w-full h-full rounded-full border border-[#00D2FF]/30 animate-[spin_60s_linear_infinite] pointer-events-none" />
              <div className="absolute w-[85%] h-[85%] rounded-full border border-white/10 border-dashed animate-[spin_40s_linear_infinite_reverse] pointer-events-none" />

              {/* Orbital Image Box from Reference */}
              <div className="relative w-full h-full rounded-full overflow-hidden border border-[#00D2FF]/30 bg-[#0A0E17]/60 backdrop-blur-md shadow-[0_0_50px_rgba(0,210,255,0.3)] group">
                <img
                  src="/assets/portfolio/contact-orbital.png"
                  alt="Rayhan NWV Orbital R Emblem"
                  className="w-full h-full object-cover object-center filter contrast-110 saturate-125 transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />

                {/* Center subtle glow */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#05070D]/70 via-transparent to-transparent pointer-events-none" />

                {/* Orbital Star Accents */}
                <div className="absolute top-1/4 right-8 w-2 h-2 rounded-full bg-white shadow-[0_0_10px_#FFFFFF] animate-pulse" />
                <div className="absolute bottom-1/3 left-8 w-1.5 h-1.5 rounded-full bg-[#00D2FF] shadow-[0_0_8px_#00D2FF] animate-pulse" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
