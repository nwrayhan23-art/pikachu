import React, { useRef, useEffect } from 'react';
import { ArrowRight, Code2, Globe, Cpu, Layers } from 'lucide-react';
import { PROFILE_DATA } from '../../data/profile';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const About: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const visualRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
      }

      gsap.fromTo(
        contentRef.current?.children || [],
        { opacity: 0, y: 35 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 75%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        visualRef.current,
        { opacity: 0, x: 40 },
        {
          opacity: 1,
          x: 0,
          duration: 1.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 75%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const techPills = [
    { label: 'Programming & Logic', icon: Code2 },
    { label: 'Modern Web Architecture', icon: Globe },
    { label: 'Generative AI Systems', icon: Cpu },
    { label: 'Blockchain & Protocols', icon: Layers },
  ];

  const handleLearnMoreClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const el = document.getElementById('expertise');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-[#05070D] border-t border-white/[0.06] overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 right-1/4 w-[400px] h-[400px] bg-[#00D2FF]/8 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Narrative Content */}
          <div ref={contentRef} className="lg:col-span-7 flex flex-col items-start">
            {/* Section Index Indicator */}
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-sm tracking-widest text-[#00D2FF] font-semibold">
                {PROFILE_DATA.about.sectionIndex}
              </span>
              <div className="w-8 h-[1px] bg-[#00D2FF]/40" />
              <span className="font-mono text-xs uppercase tracking-widest text-[#8E9BB0]">
                PROFILE OVERVIEW
              </span>
            </div>

            {/* Section Title */}
            <h2 className="text-3xl sm:text-5xl md:text-6xl font-display font-bold text-white tracking-tight mb-8">
              {PROFILE_DATA.about.sectionTitle}{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D2FF] to-[#0066FF] glow-cyan">
                {PROFILE_DATA.about.sectionTitleAccent}
              </span>
            </h2>

            {/* Editorial Bio Content */}
            <div className="space-y-6 text-base sm:text-lg text-[#8E9BB0] leading-relaxed max-w-2xl mb-8">
              <p className="text-white text-lg sm:text-xl font-medium">
                {PROFILE_DATA.about.greeting}{' '}
                <span className="text-[#8E9BB0] font-normal">
                  {PROFILE_DATA.about.bioParagraph1}
                </span>
              </p>
              <p>{PROFILE_DATA.about.bioParagraph2}</p>
            </div>

            {/* Capability Interest Chips */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-xl mb-10">
              {techPills.map((pill, idx) => {
                const Icon = pill.icon;
                return (
                  <div
                    key={idx}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.08] hover:border-[#00D2FF]/40 hover:bg-white/[0.06] transition-all"
                  >
                    <Icon className="w-4 h-4 text-[#00D2FF]" />
                    <span className="text-sm font-medium text-white">{pill.label}</span>
                  </div>
                );
              })}
            </div>

            {/* Learn More CTA */}
            <a
              href="#expertise"
              onClick={handleLearnMoreClick}
              className="group inline-flex items-center gap-3 px-6 py-3.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-white font-medium text-sm border border-white/[0.12] hover:border-[#00D2FF]/50 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.4)]"
            >
              <span>Learn More</span>
              <ArrowRight className="w-4 h-4 text-[#00D2FF] transition-transform group-hover:translate-x-1" />
            </a>
          </div>

          {/* Right Column: Cyberpunk Developer Portrait */}
          <div ref={visualRef} className="lg:col-span-5 flex justify-center lg:justify-end">
            <div className="relative w-full max-w-[420px] rounded-2xl overflow-hidden border border-white/[0.1] bg-[#0A0E17]/80 backdrop-blur-md shadow-[0_20px_60px_rgba(0,0,0,0.8)] group">
              {/* Outer atmospheric aura */}
              <div className="absolute -inset-1 bg-gradient-to-tr from-[#0066FF]/20 via-[#00D2FF]/30 to-transparent blur-xl opacity-60 group-hover:opacity-100 transition-opacity pointer-events-none" />

              {/* Developer Portrait Image */}
              <div className="relative aspect-[4/3] sm:aspect-square overflow-hidden">
                <img
                  src={PROFILE_DATA.about.avatarImage}
                  alt="Rayhan NWV Developer Portrait in Cyberpunk Blue Lighting"
                  className="w-full h-full object-cover object-center filter contrast-115 transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />

                {/* Vertical Branding Overlay matching the reference mockup */}
                <div className="absolute top-4 right-4 writing-vertical-lr font-mono text-[11px] tracking-[0.3em] uppercase text-white/50 select-none flex items-center gap-2">
                  <span>RAYHAN NWV</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00D2FF]" />
                </div>

                {/* Bottom glass metadata banner */}
                <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-[#05070D] via-[#05070D]/80 to-transparent flex items-center justify-between text-xs font-mono">
                  <span className="text-white font-medium">INNOVATOR & DEVELOPER</span>
                  <span className="text-[#00D2FF]">EXPLORER</span>
                </div>
              </div>

              {/* Tech corner tick marks */}
              <div className="absolute top-2 left-2 w-2.5 h-2.5 border-t border-l border-[#00D2FF]" />
              <div className="absolute top-2 right-2 w-2.5 h-2.5 border-t border-r border-[#00D2FF]" />
              <div className="absolute bottom-2 left-2 w-2.5 h-2.5 border-b border-l border-[#00D2FF]" />
              <div className="absolute bottom-2 right-2 w-2.5 h-2.5 border-b border-r border-[#00D2FF]" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
