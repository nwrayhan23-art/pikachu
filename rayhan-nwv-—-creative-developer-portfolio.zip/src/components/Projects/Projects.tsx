import React, { useState, useRef, useEffect } from 'react';
import { ArrowUpRight, ArrowRight, Github } from 'lucide-react';
import { PROJECTS_HEADER, PROJECTS_DATA, ProjectItem } from '../../data/projects';
import { ProjectModal } from '../ui/ProjectModal';
import { PROFILE_DATA } from '../../data/profile';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const Projects: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
      }

      gsap.fromTo(
        headerRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 75%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        gridRef.current?.children || [],
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: gridRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="projects"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-[#05070D] border-t border-white/[0.06] overflow-hidden"
    >
      {/* Background glow */}
      <div className="absolute top-1/3 left-10 w-96 h-96 bg-[#0066FF]/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start mb-12">
          {/* Section Header */}
          <div ref={headerRef} className="lg:col-span-4 flex flex-col items-start">
            {/* Section Index */}
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-sm tracking-widest text-[#00D2FF] font-semibold">
                {PROJECTS_HEADER.sectionIndex}
              </span>
              <div className="w-8 h-[1px] bg-[#00D2FF]/40" />
              <span className="font-mono text-xs uppercase tracking-widest text-[#8E9BB0]">
                PORTFOLIO
              </span>
            </div>

            <h2 className="text-3xl sm:text-5xl md:text-6xl font-display font-bold text-white tracking-tight mb-4">
              {PROJECTS_HEADER.sectionTitle}{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D2FF] to-[#0066FF] glow-cyan">
                {PROJECTS_HEADER.sectionTitleAccent}
              </span>
            </h2>

            <p className="text-sm sm:text-base text-[#8E9BB0] leading-relaxed max-w-sm mb-8">
              {PROJECTS_HEADER.subtitle}
            </p>

            <a
              href={PROFILE_DATA.contact.github.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-3 px-6 py-3.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-white font-medium text-sm border border-white/[0.1] hover:border-[#00D2FF]/50 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.4)]"
            >
              <Github className="w-4 h-4 text-[#00D2FF]" />
              <span>{PROJECTS_HEADER.ctaLabel}</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </a>
          </div>

          {/* 2x2 Project Cards Grid matching reference layout */}
          <div
            ref={gridRef}
            className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-5 sm:gap-6"
          >
            {PROJECTS_DATA.map((project) => (
              <div
                key={project.id}
                onClick={() => setSelectedProject(project)}
                className="group relative flex flex-col rounded-2xl bg-[#0A0E17]/90 border border-white/[0.08] hover:border-[#00D2FF]/50 transition-all duration-300 overflow-hidden cursor-pointer shadow-[0_10px_30px_rgba(0,0,0,0.6)] hover:shadow-[0_15px_40px_rgba(0,210,255,0.15)] hover:-translate-y-1 focus-within:ring-2 focus-within:ring-[#00D2FF]"
              >
                {/* Project Image Banner */}
                <div className="relative h-40 sm:h-44 bg-[#05070D] overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover object-center filter contrast-110 saturate-120 transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0A0E17] via-transparent to-transparent opacity-80" />

                  {/* Corner Accent */}
                  <div className="absolute top-3 right-3 p-1.5 rounded-lg bg-black/60 border border-white/10 text-white/70 group-hover:text-[#00D2FF] group-hover:border-[#00D2FF]/40 transition-colors">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>

                {/* Card Information */}
                <div className="p-5 flex flex-col justify-between flex-grow">
                  <div>
                    <h3 className="text-lg sm:text-xl font-display font-bold text-white group-hover:text-[#00D2FF] transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-xs font-mono text-[#8E9BB0] mt-1">
                      {project.category}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/[0.06] flex items-center justify-between">
                    <div className="flex flex-wrap gap-1.5">
                      {project.techStack.slice(0, 3).map((tech) => (
                        <span
                          key={tech}
                          className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/[0.04] text-[#8E9BB0]"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                    <span className="text-[11px] font-mono text-[#00D2FF]/80 group-hover:text-[#00D2FF] transition-colors">
                      Details →
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Project Deep Dive Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </section>
  );
};
