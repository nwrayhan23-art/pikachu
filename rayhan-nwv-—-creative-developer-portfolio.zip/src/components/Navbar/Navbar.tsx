import React, { useState, useEffect } from 'react';
import { BrandLogo } from '../ui/BrandLogo';
import { PROFILE_DATA } from '../../data/profile';
import { Menu, X, Sparkles } from 'lucide-react';

interface NavbarProps {
  activeSection: string;
}

export const Navbar: React.FC<NavbarProps> = ({ activeSection }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [glowActive, setGlowActive] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on resize to desktop
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsMobileMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMobileMenuOpen]);

  const handleNavClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    href: string
  ) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      setIsMobileMenuOpen(false);
      element.scrollIntoView({ behavior: 'smooth' });
      window.history.pushState(null, '', href);
    }
  };

  const toggleGlowEffect = () => {
    setGlowActive((prev) => !prev);
    // Subtle visual pulse effect
    document.documentElement.classList.toggle('high-contrast-glow');
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#05070D]/85 backdrop-blur-md border-b border-white/[0.08] py-3.5 shadow-[0_10px_30px_rgba(0,0,0,0.5)]'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <BrandLogo size="md" />

        {/* Desktop Navigation */}
        <nav
          aria-label="Main Navigation"
          className="hidden md:flex items-center gap-1 lg:gap-2 px-3 py-1.5 rounded-full bg-white/[0.03] border border-white/[0.07] backdrop-blur-sm"
        >
          {PROFILE_DATA.navLinks.map((link) => {
            const isActive = activeSection === link.id;
            return (
              <a
                key={link.id}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className={`relative px-4 py-1.5 text-sm font-medium transition-all duration-200 rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF] ${
                  isActive
                    ? 'text-white font-semibold'
                    : 'text-[#8E9BB0] hover:text-white'
                }`}
                aria-current={isActive ? 'page' : undefined}
              >
                {isActive && (
                  <span className="absolute inset-0 bg-gradient-to-r from-[#0066FF]/40 to-[#00D2FF]/40 border border-[#00D2FF]/40 rounded-full shadow-[0_0_12px_rgba(0,210,255,0.4)] -z-10" />
                )}
                {link.label}
              </a>
            );
          })}
        </nav>

        {/* Right Action: Atmosphere / Light toggle */}
        <div className="hidden md:flex items-center gap-3">
          <button
            onClick={toggleGlowEffect}
            aria-label="Toggle atmospheric pulse"
            title="Atmosphere Glow"
            className="p-2 rounded-full text-[#8E9BB0] hover:text-[#00D2FF] hover:bg-white/[0.06] transition-all border border-transparent hover:border-[#00D2FF]/30 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF]"
          >
            <Sparkles className={`w-4 h-4 ${glowActive ? 'text-[#00D2FF] animate-pulse' : ''}`} />
          </button>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex md:hidden items-center gap-2">
          <button
            onClick={toggleGlowEffect}
            aria-label="Toggle atmospheric pulse"
            className="p-2 rounded-lg text-[#8E9BB0] hover:text-[#00D2FF] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF]"
          >
            <Sparkles className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-expanded={isMobileMenuOpen}
            aria-label="Toggle menu"
            className="p-2 rounded-lg text-white bg-white/[0.05] border border-white/[0.1] hover:bg-white/[0.1] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF]"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-x-0 top-[60px] bottom-0 bg-[#05070D]/95 backdrop-blur-xl border-t border-white/[0.08] z-50 flex flex-col justify-between p-6 overflow-y-auto">
          <div className="flex flex-col gap-3 pt-4">
            <span className="text-xs font-mono uppercase tracking-widest text-[#8E9BB0] mb-2 px-3">
              Navigation Menu
            </span>
            {PROFILE_DATA.navLinks.map((link, idx) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.id}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className={`flex items-center justify-between px-4 py-3.5 rounded-xl text-lg font-display tracking-wider border transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-[#0066FF]/20 to-[#00D2FF]/20 border-[#00D2FF]/40 text-white font-bold shadow-[0_0_15px_rgba(0,210,255,0.2)]'
                      : 'border-white/[0.06] bg-white/[0.02] text-[#8E9BB0] hover:text-white hover:border-white/[0.15]'
                  }`}
                >
                  <span className="flex items-center gap-3">
                    <span className="text-xs font-mono text-[#00D2FF]">0{idx + 1}</span>
                    {link.label}
                  </span>
                  {isActive && (
                    <span className="w-2 h-2 rounded-full bg-[#00D2FF] shadow-[0_0_8px_#00D2FF]" />
                  )}
                </a>
              );
            })}
          </div>

          {/* Quick contact shortcuts in mobile drawer */}
          <div className="pt-6 border-t border-white/[0.08] flex flex-col gap-3">
            <a
              href={PROFILE_DATA.contact.github.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-white/[0.04] border border-white/[0.08] text-sm font-medium text-white hover:border-[#00D2FF]/40 transition-colors"
            >
              GitHub Profile ↗
            </a>
            <a
              href={PROFILE_DATA.contact.whatsapp.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#0066FF] to-[#00D2FF] text-sm font-semibold text-white shadow-[0_0_20px_rgba(0,210,255,0.4)]"
            >
              Chat on WhatsApp
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
