import React from 'react';

interface BrandLogoProps {
  className?: string;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  showText = true,
  size = 'md',
}) => {
  const iconSizes = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-10 h-10',
  };

  const textSizes = {
    sm: 'text-sm tracking-wider',
    md: 'text-base sm:text-lg tracking-wider',
    lg: 'text-xl sm:text-2xl tracking-widest',
  };

  return (
    <a
      href="#home"
      aria-label="RAYHAN NWV Home"
      className={`group flex items-center gap-2.5 transition-opacity hover:opacity-90 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF] rounded-lg ${className}`}
    >
      {/* Precision Futuristic R Emblem */}
      <div className={`relative ${iconSizes[size]} shrink-0 flex items-center justify-center`}>
        <svg
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-[0_0_12px_rgba(0,210,255,0.7)] group-hover:drop-shadow-[0_0_18px_rgba(0,210,255,0.9)] transition-all duration-300"
        >
          <defs>
            <linearGradient id="logo-blue-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00D2FF" />
              <stop offset="50%" stopColor="#0088FF" />
              <stop offset="100%" stopColor="#0044FF" />
            </linearGradient>
            <linearGradient id="logo-chrome-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="70%" stopColor="#C8E4FF" />
              <stop offset="100%" stopColor="#769CBF" />
            </linearGradient>
          </defs>

          {/* Left angled stem */}
          <path
            d="M20 18H44C62 18 74 27 74 42C74 53 66 60 54 64L76 86H58L40 66H34V86H20V18Z"
            fill="url(#logo-blue-grad)"
          />
          {/* Inner cutout */}
          <path
            d="M34 32H44C51 32 58 35 58 42C58 49 51 52 44 52H34V32Z"
            fill="#05070D"
          />
          {/* Futuristic diagonal slash highlight */}
          <path
            d="M52 48L72 82H60L44 54H52Z"
            fill="url(#logo-chrome-grad)"
            opacity="0.9"
          />
        </svg>
      </div>

      {showText && (
        <span
          className={`font-display font-bold uppercase text-white tracking-widest ${textSizes[size]}`}
        >
          RAYHAN <span className="text-[#00D2FF]">NWV.</span>
        </span>
      )}
    </a>
  );
};
