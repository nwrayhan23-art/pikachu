import React, { useEffect } from 'react';
import { X, ExternalLink, Github, Tag, Calendar } from 'lucide-react';
import { ProjectItem } from '../../data/projects';

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-8 bg-black/80 backdrop-blur-md animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl bg-[#0A0E17] border border-white/[0.12] rounded-2xl overflow-hidden shadow-[0_25px_60px_rgba(0,0,0,0.9)] max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header Media */}
        <div className="relative h-48 sm:h-64 bg-[#05070D] overflow-hidden border-b border-white/[0.08]">
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover object-center filter contrast-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0E17] via-[#0A0E17]/40 to-transparent" />

          {/* Close button */}
          <button
            onClick={onClose}
            aria-label="Close project details"
            className="absolute top-4 right-4 p-2 rounded-full bg-black/60 hover:bg-black/90 text-white border border-white/20 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF]"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Status Badge */}
          <div className="absolute bottom-4 left-6 flex items-center gap-3">
            <span className="px-3 py-1 rounded-full text-xs font-mono font-medium bg-[#00D2FF]/20 border border-[#00D2FF]/40 text-[#00D2FF]">
              {project.statusBadge}
            </span>
            <span className="text-xs font-mono text-[#8E9BB0] flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {project.releaseYear}
            </span>
          </div>
        </div>

        {/* Modal Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-[#00D2FF]">
              {project.category}
            </span>
            <h3
              id="modal-title"
              className="text-2xl sm:text-3xl font-display font-bold text-white mt-1"
            >
              {project.title}
            </h3>
          </div>

          <p className="text-base text-[#8E9BB0] leading-relaxed">
            {project.fullDescription}
          </p>

          {/* Tech Stack */}
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-[#8E9BB0] uppercase tracking-wider mb-3">
              <Tag className="w-3.5 h-3.5 text-[#00D2FF]" />
              <span>Technologies & Architecture</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {project.techStack.map((tech) => (
                <span
                  key={tech}
                  className="px-3 py-1.5 rounded-lg text-xs font-mono bg-white/[0.04] border border-white/[0.08] text-white"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Action Links */}
          <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-white/[0.08]">
            <a
              href={project.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-white text-sm font-medium border border-white/[0.1] hover:border-[#00D2FF]/40 transition-colors"
            >
              <Github className="w-4 h-4 text-[#00D2FF]" />
              <span>Explore GitHub Repository</span>
              <ExternalLink className="w-3.5 h-3.5 text-[#8E9BB0]" />
            </a>

            {project.demoUrl && (
              <a
                href={project.demoUrl}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#0066FF] to-[#00D2FF] text-white text-sm font-semibold shadow-[0_0_15px_rgba(0,210,255,0.3)] hover:shadow-[0_0_25px_rgba(0,210,255,0.5)] transition-all"
                onClick={() => {
                  if (project.demoUrl?.startsWith('#')) {
                    onClose();
                  }
                }}
              >
                <span>Live View / Concept</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
