import React, { useRef, useEffect } from 'react';
import { ArrowRight, Mail, ChevronDown } from 'lucide-react';
import { PROFILE_DATA } from '../../data/profile';
import gsap from 'gsap';

export const Hero: React.FC = () => {
  const containerRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);
  const descRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const visualRef = useRef<HTMLDivElement>(null);
  const scrollIndicatorRef = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Respect reduced motion
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
      }

      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      tl.fromTo(
        badgeRef.current,
        { opacity: 0, y: -20 },
        { opacity: 1, y: 0, duration: 0.8, delay: 0.2 }
      )
        .fromTo(
          titleRef.current?.children || [],
          { opacity: 0, y: 40 },
          { opacity: 1, y: 0, duration: 1, stagger: 0.15 },
          '-=0.4'
        )
        .fromTo(
          descRef.current,
          { opacity: 0, y: 25 },
          { opacity: 1, y: 0, duration: 0.8 },
          '-=0.6'
        )
        .fromTo(
          ctaRef.current?.children || [],
          { opacity: 0, scale: 0.95, y: 15 },
          { opacity: 1, scale: 1, y: 0, duration: 0.6, stagger: 0.1 },
          '-=0.5'
        )
        .fromTo(
          visualRef.current,
          { opacity: 0, scale: 0.9, rotateY: 10 },
          { opacity: 1, scale: 1, rotateY: 0, duration: 1.2 },
          '-=0.9'
        )
        .fromTo(
          scrollIndicatorRef.current,
          { opacity: 0 },
          { opacity: 1, duration: 0.8 },
          '-=0.3'
        );

      // Subtle float animation for the hero emblem
      gsap.to(visualRef.current, {
        y: -12,
        duration: 3.5,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });
    }, containerRef);

    return () => ctx.revert();
  }, []);

  const handleScrollClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      ref={containerRef}
      className="relative min-h-screen pt-28 pb-16 md:pt-36 md:pb-24 flex flex-col justify-center overflow-hidden tech-grid-bg"
    >
      {/* Ambient background glows */}
      <div className="absolute top-1/4 -left-48 w-96 h-96 bg-[#0066FF]/15 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-1/3 right-0 w-[550px] h-[550px] bg-[#00D2FF]/15 rounded-full blur-[160px] pointer-events-none" />

      {/* Subtle orbital lines in background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
        <div className="w-[800px] h-[800px] rounded-full border border-[#00D2FF]/20 animate-[spin_120s_linear_infinite]" />
        <div className="absolute w-[1200px] h-[1200px] rounded-full border border-white/5" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Editorial Headline & Actions */}
          <div className="lg:col-span-7 flex flex-col items-start">
            {/* Identity Subtitle */}
            <div
              ref={badgeRef}
              className="inline-flex items-center gap-3 px-3.5 py-1.5 rounded-full bg-white/[0.04] border border-white/[0.08] backdrop-blur-sm mb-6"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#00D2FF] shadow-[0_0_8px_#00D2FF] animate-pulse" />
              <span className="font-mono text-xs uppercase tracking-[0.3em] text-[#8E9BB0]">
                R A Y H A N &nbsp; N W V .
              </span>
            </div>

            {/* Main Editorial Headline */}
            <h1
              ref={titleRef}
              className="text-4xl sm:text-6xl md:text-7xl xl:text-8xl font-display font-extrabold tracking-tight text-white leading-[1.05] mb-6"
            >
              <span className="block">{PROFILE_DATA.headline}</span>
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#00D2FF] via-[#38BDF8] to-[#0066FF] glow-cyan">
                {PROFILE_DATA.headlineAccent}
              </span>
            </h1>

            {/* Supporting Bio Text */}
            <p
              ref={descRef}
              className="text-base sm:text-lg md:text-xl text-[#8E9BB0] font-normal max-w-xl leading-relaxed mb-10"
            >
              {PROFILE_DATA.subheadline}
            </p>

            {/* CTAs */}
            <div
              ref={ctaRef}
              className="flex flex-wrap items-center gap-4 sm:gap-5 w-full sm:w-auto"
            >
              <a
                href="#projects"
                onClick={(e) => handleScrollClick(e, '#projects')}
                className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-gradient-to-r from-[#0066FF] to-[#00D2FF] text-white font-semibold text-base shadow-[0_0_25px_rgba(0,210,255,0.4)] hover:shadow-[0_0_35px_rgba(0,210,255,0.6)] hover:scale-[1.02] active:scale-[0.98] transition-all duration-300 w-full sm:w-auto"
              >
                <span>View Projects</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </a>

              <a
                href="#contact"
                onClick={(e) => handleScrollClick(e, '#contact')}
                className="inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-white font-medium text-base border border-white/[0.1] hover:border-[#00D2FF]/40 transition-all duration-300 w-full sm:w-auto"
              >
                <Mail className="w-4 h-4 text-[#00D2FF]" />
                <span>Contact Me</span>
              </a>
            </div>
          </div>

          {/* Right Column: Holographic Futuristic Emblem & Horizon */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end relative">
            <div
              ref={visualRef}
              className="relative w-full max-w-[420px] sm:max-w-[480px] aspect-square flex items-center justify-center"
            >
              {/* Outer atmospheric glowing aura */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#0066FF]/20 via-[#00D2FF]/25 to-transparent blur-3xl pointer-events-none" />

              {/* High-tech orbital circles */}
              <div className="absolute w-[90%] h-[90%] rounded-full border border-[#00D2FF]/30 border-dashed animate-[spin_90s_linear_infinite] pointer-events-none" />
              <div className="absolute w-[75%] h-[75%] rounded-full border border-white/10 pointer-events-none" />

              {/* Curved horizon and high-res metallic R emblem */}
              <div className="relative w-full h-full rounded-2xl overflow-hidden border border-white/[0.08] bg-[#05070D]/60 backdrop-blur-sm shadow-[0_20px_50px_rgba(0,0,0,0.8)] group">
                <img
                  src="/assets/portfolio/hero-r-emblem.png"
                  alt="Rayhan NWV Futuristic R Emblem with Cosmic Horizon"
                  className="w-full h-full object-cover object-center filter contrast-110 saturate-125 transition-transform duration-700 group-hover:scale-105"
                  loading="eager"
                />

                {/* Cyberpunk corner accents */}
                <div className="absolute top-2 left-2 w-3 h-3 border-t-2 border-l-2 border-[#00D2FF]/70" />
                <div className="absolute top-2 right-2 w-3 h-3 border-t-2 border-r-2 border-[#00D2FF]/70" />
                <div className="absolute bottom-2 left-2 w-3 h-3 border-b-2 border-l-2 border-[#00D2FF]/70" />
                <div className="absolute bottom-2 right-2 w-3 h-3 border-b-2 border-r-2 border-[#00D2FF]/70" />

                {/* Subtle telemetry overlay */}
                <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[10px] font-mono text-[#8E9BB0]/80">
                  <span className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00D2FF] animate-ping" />
                    CORE / ACTIVE
                  </span>
                  <span>LATENCY 0.08ms</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Left Scroll Indicator */}
        <div className="mt-16 sm:mt-20 flex items-center justify-between">
          <a
            ref={scrollIndicatorRef}
            href="#about"
            onClick={(e) => handleScrollClick(e, '#about')}
            className="group inline-flex items-center gap-3 text-xs font-mono uppercase tracking-widest text-[#8E9BB0] hover:text-[#00D2FF] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF] rounded-lg p-1"
          >
            <div className="w-5 h-9 rounded-full border border-white/20 group-hover:border-[#00D2FF]/60 flex items-start justify-center p-1.5 transition-colors">
              <span className="w-1 h-2 rounded-full bg-[#00D2FF] animate-[bounce_2s_infinite]" />
            </div>
            <span>Scroll to explore</span>
          </a>

          <div className="hidden sm:flex items-center gap-4 text-xs font-mono text-[#8E9BB0]/60">
            <span>SEC // 00</span>
            <div className="w-12 h-[1px] bg-white/10" />
            <span className="text-[#00D2FF]">PORTFOLIO 2026</span>
          </div>
        </div>
      </div>
    </section>
  );
};
