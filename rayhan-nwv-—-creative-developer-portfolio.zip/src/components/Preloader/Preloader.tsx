import React, { useEffect, useState } from 'react';

interface PreloaderProps {
  onComplete: () => void;
}

export const Preloader: React.FC<PreloaderProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [isFading, setIsFading] = useState(false);

  useEffect(() => {
    // Check for autostart or reduced motion
    const searchParams = new URLSearchParams(window.location.search);
    const autostart = searchParams.get('autostart') === '1';
    const prefersReducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    if (autostart || prefersReducedMotion) {
      onComplete();
      return;
    }

    // High performance progress counter
    const startTime = performance.now();
    const duration = 1100; // Fast 1.1s total duration, snappy and non-blocking

    const updateCounter = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const currentProgress = Math.min(100, Math.floor((elapsed / duration) * 100));
      setProgress(currentProgress);

      if (elapsed < duration) {
        requestAnimationFrame(updateCounter);
      } else {
        setIsFading(true);
        setTimeout(() => {
          onComplete();
        }, 400);
      }
    };

    const animId = requestAnimationFrame(updateCounter);
    return () => cancelAnimationFrame(animId);
  }, [onComplete]);

  return (
    <div
      role="status"
      aria-live="polite"
      aria-label="Loading portfolio"
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#05070D] transition-opacity duration-400 ease-out ${
        isFading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background ambient radial glow */}
      <div className="absolute w-[500px] h-[500px] rounded-full bg-[#00D2FF]/5 blur-[120px] pointer-events-none" />

      <div className="relative z-10 flex flex-col items-center max-w-sm px-6 text-center">
        {/* Animated Brand Wordmark */}
        <div className="flex items-center gap-2 mb-8">
          <div className="w-10 h-10 relative">
            <svg
              viewBox="0 0 100 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="w-full h-full drop-shadow-[0_0_15px_rgba(0,210,255,0.8)]"
            >
              <defs>
                <linearGradient id="pre-r-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#00D2FF" />
                  <stop offset="100%" stopColor="#0066FF" />
                </linearGradient>
              </defs>
              <path
                d="M20 18H44C62 18 74 27 74 42C74 53 66 60 54 64L76 86H58L40 66H34V86H20V18Z"
                fill="url(#pre-r-grad)"
              />
              <path
                d="M34 32H44C51 32 58 35 58 42C58 49 51 52 44 52H34V32Z"
                fill="#05070D"
              />
            </svg>
          </div>
          <span className="font-display font-bold text-2xl tracking-[0.25em] text-white">
            RAYHAN <span className="text-[#00D2FF]">NWV.</span>
          </span>
        </div>

        {/* Progress bar line */}
        <div className="w-48 h-[2px] bg-white/10 rounded-full overflow-hidden relative mb-4">
          <div
            className="h-full bg-gradient-to-r from-[#0066FF] to-[#00D2FF] transition-all duration-75 ease-out shadow-[0_0_10px_#00D2FF]"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Numeric progress and status */}
        <div className="flex items-center justify-between w-48 text-xs font-mono text-[#8E9BB0]">
          <span className="tracking-widest uppercase">INITIALIZING</span>
          <span className="text-[#00D2FF] font-semibold">{progress}%</span>
        </div>
      </div>
    </div>
  );
};
