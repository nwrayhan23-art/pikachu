import React from 'react';
import { Github, MessageSquare, ArrowUp } from 'lucide-react';
import { BrandLogo } from '../ui/BrandLogo';
import { PROFILE_DATA } from '../../data/profile';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const handleBackToTop = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <footer className="relative bg-[#05070D] border-t border-white/[0.08] py-12 overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[150px] bg-[#00D2FF]/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 pb-8 border-b border-white/[0.06]">
          {/* Brand Wordmark and identity */}
          <div className="flex flex-col items-center md:items-start gap-2">
            <BrandLogo size="md" />
            <p className="text-xs font-mono text-[#8E9BB0] tracking-wider">
              CRAFTED WITH PRECISION & PASSION // DIGITAL CRAFTSMANSHIP
            </p>
          </div>

          {/* Social Links and Back to top */}
          <div className="flex flex-wrap items-center justify-center gap-6">
            <button
              onClick={handleBackToTop}
              className="group inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#8E9BB0] hover:text-[#00D2FF] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF] rounded-lg px-3 py-1.5 bg-white/[0.02] border border-white/[0.06] hover:border-[#00D2FF]/40"
            >
              <span>Back to top</span>
              <ArrowUp className="w-3.5 h-3.5 transition-transform group-hover:-translate-y-0.5" />
            </button>

            <div className="flex items-center gap-3">
              <a
                href={PROFILE_DATA.contact.github.url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="GitHub Profile"
                className="p-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-[#8E9BB0] hover:text-[#00D2FF] hover:border-[#00D2FF]/40 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF]"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href={PROFILE_DATA.contact.whatsapp.url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp Message"
                className="p-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-[#8E9BB0] hover:text-[#00D2FF] hover:border-[#00D2FF]/40 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00D2FF]"
              >
                <MessageSquare className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom copyright line */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-[#8E9BB0]/60">
          <span>
            © {currentYear} {PROFILE_DATA.brandName}. All rights reserved.
          </span>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>SYSTEMS NOMINAL // 60 FPS</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
