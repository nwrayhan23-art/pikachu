/**
 * Core portfolio utility functions
 * Pure logic decoupled from UI components for high-speed testing.
 */

import { ProjectItem } from '../data/projects';

/**
 * Formats section index into two-digit format like '01 / 05'
 */
export function formatSectionIndex(current: number, total: number = 5): string {
  const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
  return `${pad(current)} / ${pad(total)}`;
}

/**
 * Sanitizes a phone number to standard international dial format digits
 */
export function sanitizePhoneNumber(phone: string): string {
  return phone.replace(/[^\d+]/g, '').replace(/^\+/, '');
}

/**
 * Builds a direct WhatsApp chat URL with optional greeting message
 */
export function buildWhatsAppUrl(phone: string, message?: string): string {
  const cleanPhone = sanitizePhoneNumber(phone);
  const base = `https://wa.me/${cleanPhone}`;
  if (!message) return base;
  return `${base}?text=${encodeURIComponent(message)}`;
}

/**
 * Filters project list by category or returns all if 'All' is selected
 */
export function filterProjects(
  projects: ProjectItem[],
  selectedCategory: string
): ProjectItem[] {
  if (!selectedCategory || selectedCategory === 'All') {
    return projects;
  }
  return projects.filter(
    (p) =>
      p.category.toLowerCase().includes(selectedCategory.toLowerCase()) ||
      p.techStack.some((t) =>
        t.toLowerCase().includes(selectedCategory.toLowerCase())
      )
  );
}

/**
 * Safe clipboard copy with fallback for iframe sandboxes
 */
export async function copyTextToClipboard(text: string): Promise<boolean> {
  if (typeof window === 'undefined') return false;

  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (err) {
    // Fallback below
  }

  try {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    const successful = document.execCommand('copy');
    document.body.removeChild(textArea);
    return successful;
  } catch (err) {
    return false;
  }
}
