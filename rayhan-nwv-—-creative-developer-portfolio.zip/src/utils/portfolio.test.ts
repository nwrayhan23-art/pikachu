import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatSectionIndex,
  sanitizePhoneNumber,
  buildWhatsAppUrl,
  filterProjects,
} from './portfolio.js';
import { PROFILE_DATA } from '../data/profile.js';
import { PROJECTS_DATA } from '../data/projects.js';

test('formatSectionIndex creates properly padded labels', () => {
  assert.equal(formatSectionIndex(1, 5), '01 / 05');
  assert.equal(formatSectionIndex(4, 5), '04 / 05');
  assert.equal(formatSectionIndex(10, 12), '10 / 12');
});

test('sanitizePhoneNumber extracts correct digits for WhatsApp', () => {
  const raw = '+62 882-0038-15325';
  const sanitized = sanitizePhoneNumber(raw);
  assert.equal(sanitized, '62882003815325');
});

test('buildWhatsAppUrl generates correct link without modifying official number', () => {
  const url = buildWhatsAppUrl('+62 882-0038-15325');
  assert.equal(url, 'https://wa.me/62882003815325');

  const withMsg = buildWhatsAppUrl('+62 882-0038-15325', 'Hello Rayhan!');
  assert.equal(withMsg, 'https://wa.me/62882003815325?text=Hello%20Rayhan!');
});

test('profile data matches exact required contact specifications', () => {
  assert.equal(PROFILE_DATA.contact.github.url, 'https://github.com/nwrayhan23-art/');
  assert.equal(PROFILE_DATA.contact.whatsapp.display, '+62 882-0038-15325');
  assert.equal(PROFILE_DATA.contact.whatsapp.url, 'https://wa.me/62882003815325');
  assert.equal(PROFILE_DATA.brandName, 'RAYHAN NWV');
});

test('filterProjects handles filtering by category and All', () => {
  const allProjects = filterProjects(PROJECTS_DATA, 'All');
  assert.equal(allProjects.length, PROJECTS_DATA.length);

  const cryptoProjects = filterProjects(PROJECTS_DATA, 'Crypto');
  assert.equal(cryptoProjects.length >= 1, true);
  assert.equal(cryptoProjects[0].title, 'Rayhan Capital');
});
