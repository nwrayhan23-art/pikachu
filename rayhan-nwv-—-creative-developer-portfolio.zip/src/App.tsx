import { useState, useEffect } from 'react';
import { Preloader } from './components/Preloader/Preloader';
import { Navbar } from './components/Navbar/Navbar';
import { Hero } from './components/Hero/Hero';
import { About } from './components/About/About';
import { Projects } from './components/Projects/Projects';
import { Expertise } from './components/Expertise/Expertise';
import { Contact } from './components/Contact/Contact';
import { Footer } from './components/Footer/Footer';

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    // Section observer for updating active nav state
    const sections = ['home', 'about', 'projects', 'expertise', 'contact'];
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 250;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isLoading]);

  return (
    <div className="relative min-h-screen bg-[#05070D] text-white selection:bg-[#00D2FF]/30 selection:text-[#00D2FF] font-sans antialiased overflow-x-hidden">
      {/* Preloader */}
      {isLoading && <Preloader onComplete={() => setIsLoading(false)} />}

      {/* Main Header / Navigation */}
      <Navbar activeSection={activeSection} />

      {/* Main Portfolio Sections */}
      <main id="main-content" className="relative z-10">
        <Hero />
        <About />
        <Projects />
        <Expertise />
        <Contact />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
